from cryptography.fernet import Fernet

key = Fernet.generate_key()
f = Fernet(key)

message = b"Cybersecurity Demo Message"
encrypted = f.encrypt(message)
decrypted = f.decrypt(encrypted)

print("Key:", key)
print("Encrypted:", encrypted)
print("Decrypted:", decrypted)
