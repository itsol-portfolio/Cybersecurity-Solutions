Cybersecurity-Tools sample script.
Demonstrates encryption/decryption using Fernet (symmetric encryption).
